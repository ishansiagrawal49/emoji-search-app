declare type EmojiList = ReadonlyArray<{
  title: string;
  symbol: string;
  keywords: string;
}>;
