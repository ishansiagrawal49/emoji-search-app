declare type InputProps = {
  handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
};
